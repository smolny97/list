﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.Xml;

namespace timp2_var9_lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        XmlDocument xmlDoc = new XmlDocument();

        private void button1_Click(object sender, EventArgs e)
        {
            xmlDoc.PreserveWhitespace = true;
            xmlDoc.LoadXml("<Студент>\n" +
                           "  <Фамилия>Вдовкин</Фамилия>\n" +
                           "  <Имя>Пётр</Имя>\n" +
                           "  <Отчество>Михайлович</Отчество>\n" +
                           "  <Дата_рождения>01.01.2001</Дата_рождения>\n" +
                           "  <Специальность>Программирование</Специальность>\n" +
                           "  <Группа>ААА-111</Группа>\n" +
                           "  <Курс>2</Курс>\n" +
                           "  <Номер_студенческого_билета>123456</Номер_студенческого_билета>\n" +
                           "</Студент>");
            richTextBox1.Text = xmlDoc.OuterXml;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "XML файлы (*.xml)|*.xml";
            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                StreamWriter writer = new StreamWriter(saveDialog.FileName);
                writer.Write(xmlDoc.OuterXml);
                writer.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            xmlDoc.PreserveWhitespace = true;
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = "XML файлы (*.xml)|*.xml";
            if (openDialog.ShowDialog() == DialogResult.OK)
            {
                xmlDoc.Load(openDialog.FileName);
                richTextBox1.Text = xmlDoc.OuterXml;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            XmlElement grade = xmlDoc.CreateElement("Оценка");
            grade.InnerText = textBox1.Text;
            xmlDoc.DocumentElement.AppendChild(grade);
            richTextBox1.Text = xmlDoc.OuterXml;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            XmlNode node = xmlDoc.GetElementsByTagName(textBox2.Text)[0];
            xmlDoc.GetElementsByTagName(textBox3.Text)[0].AppendChild(node);
            richTextBox1.Text = xmlDoc.OuterXml;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            SignedXml signedXml = new SignedXml(xmlDoc);
            DSA key = DSA.Create();
            signedXml.SigningKey = key;
            System.Security.Cryptography.Xml.DataObject dataObject = new System.Security.Cryptography.Xml.DataObject();
            dataObject.Data = xmlDoc.ChildNodes;
            dataObject.Id = textBox4.Text;
            signedXml.AddObject(dataObject);
            Reference reference = new Reference();
            reference.Uri = "#" + textBox4.Text;
            signedXml.AddReference(reference);
            KeyInfo keyInfo = new KeyInfo();
            keyInfo.AddClause(new DSAKeyValue(key));
            signedXml.KeyInfo = keyInfo;
            signedXml.ComputeSignature();
            XmlElement xmlSignature = signedXml.GetXml();
            xmlDoc.LoadXml(xmlSignature.OuterXml);
            richTextBox1.Text = xmlDoc.OuterXml;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            SignedXml signedXml = new SignedXml();
            signedXml.LoadXml((XmlElement)xmlDoc.GetElementsByTagName("Signature")[0]);
            DSACryptoServiceProvider key = new DSACryptoServiceProvider();
            XmlElement keyElement = (XmlElement)xmlDoc.GetElementsByTagName("DSAKeyValue")[0];
            key.FromXmlString(keyElement.OuterXml);
            if (signedXml.CheckSignature(key))
                textBox5.Text = "Подпись верна";
            else
                textBox5.Text = "Подпись неверна";
        }
    }
}
